<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EQ extends Model
{
    protected $table = 'eq';
    public $timestamps = false;
}
