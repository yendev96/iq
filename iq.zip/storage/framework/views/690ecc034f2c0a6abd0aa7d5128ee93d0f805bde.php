<?php $__env->startSection('title', 'Test IQ Online'); ?>
<?php $__env->startSection('des', 'Test IQ Online'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12 box-item">
			<div class="col-md-6 left-box-item">
				<img src="<?php echo e(asset('public/frontend/img/img1.png')); ?>" alt="" style="width: 100%;">
			</div>
			<div class="col-md-6 right-box-item">
				<h2>It’s so incredible to finally be understood.</h2>
				<p>Take our Personality Test and get a 'freakishly accurate' description of who you are and why you do things the way you do.</p>
				<a href="<?php echo e(url('test-iq/for-kid')); ?>" title="" class="btn-play">PLAY TEST</a>
			</div>
		</div>

		<div class="col-md-12 box-item">
			<div class="col-md-6 left-box-item">
				<img src="<?php echo e(asset('public/frontend/img/img1.png')); ?>" alt="" style="width: 100%;">
			</div>
			<div class="col-md-6 right-box-item">
				<h2>It’s so incredible to finally be understood.</h2>
				<p>Take our Personality Test and get a 'freakishly accurate' description of who you are and why you do things the way you do.</p>
				<a href="" title="" class="btn-play">PLAY TEST</a>
			</div>
		</div>

		<div class="col-md-12 box-item">
			<div class="col-md-6 left-box-item">
				<img src="<?php echo e(asset('public/frontend/img/img1.png')); ?>" alt="" style="width: 100%;">
			</div>
			<div class="col-md-6 right-box-item">
				<h2>It’s so incredible to finally be understood.</h2>
				<p>Take our Personality Test and get a 'freakishly accurate' description of who you are and why you do things the way you do.</p>
				<a href="" title="" class="btn-play">PLAY TEST</a>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>