<!DOCTYPE html>
<html lang="en-US">
<head>
	<?php echo $__env->make('frontend.includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
	<div class="wrap">
		<header id="header" class="header text-center">
			<div class="container">
				<div class="row">
					<h1><a href="<?php echo e(url('/')); ?>" title="">IQTESTONLINE.NET</a></h1>
				</div>
			</div>
		</header><!-- /header -->

		<section id="main-website">
			<?php echo $__env->yieldContent('content'); ?>
		</section>
	</div>
	<!-- FOOTER -->
	<footer id="myfooter" class="text-center">
		<p>Copyright by iqtestonline.net</p>
	</footer>
</body>
</html>