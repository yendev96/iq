<?php $__env->startSection('title', 'Add user'); ?>
<?php $__env->startSection('content'); ?>
<section class="panel">
    <div class="panel-heading my-panel-heading">
        <div class="row">
            <div class="col-md-4 col-ms-12 title-panel">
                <h3>Add user</h3>
            </div>
           
            <div class="button-addnew pull-right">
                <a href="<?php echo e(url('backend/user/add')); ?>" class="btn btn-danger margin-inline"><i class="fa fa-plus"></i> Add</a>
            </div>
        </div>
    </div>
    <div class="panel-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="margin-bottom-50">
                    <!-- Vertical Form -->
                    <form action="<?php echo e(url('backend/user/add')); ?>" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="row">
                            <?php if(count($errors) > 0): ?>
                            <div class="thongbaoloi text-center">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-danger">
                                    <?php echo e($err); ?><br>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="l30">Email</label>
                            <input type="text" class="form-control name" name="email" placeholder="Nhập email" id="l30">
                        </div>

                        <div class="form-group">
                            <label for="l30">Username</label>
                            <input type="text" class="form-control name" name="username" placeholder="Nhập username" id="l30">
                        </div>

                        <div class="form-group">
                            <label for="l30">Password</label>
                            <input type="text" class="form-control name" name="password" placeholder="Nhập password" id="l30">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Role</label>
                            <select name="role" class="form-control">
                                <option value="1">Administrator</option>
                                <option value="2">Editor</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" name="action-question" class="btn btn-primary width-150">Submit</button>
                        </div>
                    </form>
                    <!-- End Vertical Form -->
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>