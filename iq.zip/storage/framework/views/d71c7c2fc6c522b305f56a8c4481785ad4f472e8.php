<!DOCTYPE html>
<html lang="en-US">
<head>
	<?php echo $__env->make('frontend.includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
	<div class="wrap">
		<header id="header" class="header text-center">
			<?php echo $__env->make('frontend.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</header><!-- /header -->

		<section id="main-website">
			<div class="container">
				<div class="row">
					<div class="col-md-9 main-content">
						<?php echo $__env->yieldContent('content'); ?>
					</div>
					<div class="col-md-3 sidebar">
						<?php echo $__env->make('frontend.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
			</div>
		</section>
	</div>
	<div class="box-countdown"><p id="countdown"></p></div>
	<!-- FOOTER -->
	<footer id="myfooter" class="text-center">

		<p>Copyright by iqtestonline.net</p>
	</footer>
	<?php echo $__env->yieldContent('js'); ?>
</body>
<!-- Js -->
<script src="<?php echo e(asset('/public/frontend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('/public/frontend/js/myjquery.js')); ?>"></script>
</html>