<?php $__env->startSection('title', 'Quan ly danh muc'); ?>
<?php $__env->startSection('content'); ?>
<section class="panel">
    <div class="panel-heading my-panel-heading">
        <div class="row">
            <div class="col-md-4 col-ms-12 title-panel">
                <h3>Quan ly danh muc</h3>
            </div>
            <div class="button-delete pull-right">
                <button type="button" class="btn btn-danger margin-inline">Add</button>
            </div>
            <div class="button-addnew pull-right">
                <button type="button" class="btn btn-primary margin-inline">Delete</button>
            </div>
        </div>
    </div>
    <div class="panel-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="margin-bottom-50">
                    <div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap4">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="dataTables_length" id="example1_length">
                                    <label>
                                        Show 
                                        <select name="example1_length" aria-controls="example1" class="form-control input-sm">
                                            <option value="10">10</option>
                                            <option value="25">25</option>
                                            <option value="50">50</option>
                                            <option value="100">100</option>
                                        </select>
                                        entries
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div id="example1_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control input-sm" placeholder="" aria-controls="example1"></label></div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <table class="table table-hover nowrap dataTable dtr-inline" id="example1" width="100%" role="grid" aria-describedby="example1_info" style="width: 100%;">
                                    <thead>
                                        <tr role="row">
                                            <th style="width: 164.5px;">Name</th>
                                            <th style="width: 212.5px;">Position</th>
                                            <th style="width: 183.5px;">Office</th>
                                            <th style="width: 49.5px;">Age</th>
                                            <th style="width: 96.5px;">Date</th>
                                            <th style="width: 75.5px;">Salary</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <tr role="row" class="odd">
                                            <td class="sorting_1">Ada.Hoppe</td>
                                            <td>69842 Peyton Viaduct</td>
                                            <td>South Geovannyburgh</td>
                                            <td>89</td>
                                            <td>2013/05/13</td>
                                            <td>$211,76</td>
                                        </tr>
                                        <tr role="row" class="even">
                                            <td class="sorting_1">Adrianna_Durgan</td>
                                            <td>75151 Kshlerin Square</td>
                                            <td>North Elwynfurt</td>
                                            <td>25</td>
                                            <td>2014/02/26</td>
                                            <td>$481,980</td>
                                        </tr>
                                        <tr role="row" class="odd">
                                            <td class="sorting_1">Albin.Kreiger</td>
                                            <td>111 Hershel Stream</td>
                                            <td>Hermannborough</td>
                                            <td>90</td>
                                            <td>2013/11/27</td>
                                            <td>$921,021</td>
                                        </tr>
                                        <tr role="row" class="even">
                                            <td class="sorting_1">Alisa</td>
                                            <td>64838 D'Amore Cove</td>
                                            <td>Port Lempi</td>
                                            <td>25</td>
                                            <td>2016/04/28</td>
                                            <td>$226,459</td>
                                        </tr>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>