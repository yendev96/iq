<?php $__env->startSection('title', 'Test IQ Online'); ?>
<?php $__env->startSection('des', 'Test IQ Online'); ?>
<?php $__env->startSection('content'); ?>
<div class="main-play container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2 text-center">
			<p>
				We have spent months researching and preparing this IQ test for you. It will give you a general IQ score as well as your scores on Visual Ability, Numerical Ability and Logical Reasoning.

				The first-ever IQ test that gives you a comprehensive view of your intelligence.
			</p>
			<a href="" title="" class="btn-play btn-play-detail">PLAY TEST</a>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>