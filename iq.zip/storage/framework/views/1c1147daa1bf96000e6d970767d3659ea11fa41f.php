<?php $__env->startSection('title', 'Edit Post'); ?>
<?php $__env->startSection('content'); ?>
<section class="panel">
    <div class="panel-heading my-panel-heading">
        <div class="row">
            <div class="col-md-4 col-ms-12 title-panel">
                <h3>Edit Post</h3>
            </div>
            
        </div>
    </div>
    <div class="panel-body">
        <div class="row">
            <form action="<?php echo e(url('backend/post/edit',$data->id)); ?>" method="post" enctype="multipart/form-data">
                <p class="p-error" style="color: red; font-size: 17px; text-align: center; display: none;">Không để trống</p>
                
                <div class="col-md-6">
                    <!-- Vertical Form -->
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="form-group">
                        <label for="l30">Title</label>
                        <input type="text" class="form-control title_post" value="<?php echo e($data->title); ?>" id="title" name="title_post">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="l30">Url</label>
                        <input type="text" class="form-control url" value="<?php echo e($data->slug); ?>" id="url" name="url">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="l30">Seo Title</label>
                        <input type="text" class="form-control seo_title" value="<?php echo e($data->seo_title); ?>" name="seo_title">
                    </div>
                    <div class="form-group">
                        <label for="l30">Seo Description</label>
                        <textarea class="form-control seo_description" name="seo_description"><?php echo e($data->seo_description); ?></textarea>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="l38">Content</label>
                        <textarea class="form-control content_post" id="editor1" rows="19" name="content_post"><?php echo e($data->content); ?></textarea>
                    </div>
                </div>
                 <div class="col-md-4">
                    <div class="form-group">
                        <label for="l30">Category</label>
                        <select name="article" class="form-control article">
                            <option value="">Select</option>}
                            <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php if($item->id == $data->article_id){ echo 'selected';} ?>><?php echo e($item->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="l30">Schema Active</label>
                        <select name="active_schema" class="form-control active_schema">
                            <option value="0" <?php if($data->active_schema == 0): ?><?php echo e('selected'); ?> <?php endif; ?>>Off</option>
                            <option value="1" <?php if($data->active_schema == 1): ?><?php echo e('selected'); ?> <?php endif; ?>>On</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="l30">Public</label>
                        <select name="public" class="form-control public">
                            <option value="0" <?php if($data->public == 0): ?><?php echo e('selected'); ?> <?php endif; ?>>Off</option>
                            <option value="1" <?php if($data->public == 1): ?><?php echo e('selected'); ?> <?php endif; ?>>On</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <button type="submit" name="action-question" class="btn btn-primary width-150 action-question">Submit</button>
                    </div>
                </div>

            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script>
    $('#title').keyup(function() {

        $(this).val($(this).val().replace(/\s+/g,' '));

        $('#url').val($(this).val().toLowerCase());
        $('#url').val($('#url').val().replace(/\W/g, ' '));
        $('#url').val($.trim($('#url').val()));
        $('#url').val($('#url').val().replace(/\s+/g, '-'));
    });

    $('.action-question').click(function(){
        var title              = $('.title_post').val();

        if(title == ""){
            $('.p-error').show();
            return false;
        }
    })
</script>
<script src="<?php echo e(asset('/public/backend/ckeditor/ckeditor.js')); ?>"></script>
<script src="<?php echo e(asset('/public/backend/ckfinder/ckfinder.js')); ?>"></script>
<script type="text/javascript">
    CKEDITOR.replace( 'editor1', {
        filebrowserBrowseUrl: '<?php echo e(asset('public/backend')); ?>/ckfinder/ckfinder.html',
        filebrowserUploadUrl: '<?php echo e(asset('public/backend')); ?>/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
        filebrowserWindowWidth: '1300',
        filebrowserWindowHeight: '900'
    } );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>