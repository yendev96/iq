<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
                <div class="col-xl-3 col-lg-6 col-sm-6 col-xs-12">
                    <div class="step-block ">
                        <span class="step-digit">
                            <i class="counter-icon icmn-users"><!-- --></i>
                        </span>
                        <div class="step-desc">
                            <span class="step-title">Users</span>
                            <p>
                                Total: <?php echo e($data['user_count']); ?>

                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-sm-6 col-xs-12">
                    <div class="step-block">
                        <span class="step-digit">
                            <i class="icmn-question4"><!-- --></i>
                        </span>
                        <div class="step-desc">
                            <span class="step-title">Question</span>
                            <p>Total: <?php echo e($data['question_count']); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-sm-6 col-xs-12">
                    <div class="step-block step-warning">
                        <span class="step-digit">
                            <i class="icmn-folder-upload2"><!-- --></i>
                        </span>
                        <div class="step-desc">
                            <span class="step-title">Category</span>
                            <p>
                                Total: <?php echo e($data['category']); ?>

                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-sm-6 col-xs-12">
                    <div class="step-block step-primary">
                        <span class="step-digit">
                            <i class="icmn-file-text3"><!-- --></i>
                        </span>
                        <div class="step-desc">
                            <span class="step-title">Posts</span>
                            <p>
                                Total: <?php echo e($data['post']); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>