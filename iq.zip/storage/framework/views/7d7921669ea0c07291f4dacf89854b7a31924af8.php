<?php $__env->startSection('title', 'Quản lý danh mục'); ?>
<?php $__env->startSection('content'); ?>
<section class="panel" ng-controller="categoryController">
    <div class="panel-heading my-panel-heading">
        <div class="row">
            <div class="col-md-4 col-ms-12 title-panel">
                <h3>Quản lý câu hỏi</h3>
            </div>
            <div class="button-delete pull-right">
                <button type="button" class="btn btn-primary margin-inline"><i class="fa fa-trash-o"></i> Delete</button>
            </div>
            <div class="button-addnew pull-right">
                <a href="<?php echo e(url('backend/category-manager/add')); ?>" class="btn btn-danger margin-inline"><i class="fa fa-plus"></i> Add</a>
            </div>
        </div>
    </div>
    <div class="panel-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="margin-bottom-50">
                    <div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap4">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="dataTables_length" id="example1_length">
                                    <label>
                                        <select name="example1_length" aria-controls="example1" class="form-control input-sm">
                                            <option value="10">10</option>
                                            <option value="25">25</option>
                                            <option value="50">50</option>
                                            <option value="100">100</option>
                                        </select>
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div id="example1_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control input-sm" placeholder="" aria-controls="example1"></label></div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12" style="overflow: auto;">
                                <table class="table table-hover nowrap dataTable dtr-inline" id="example1" width="100%" role="grid" aria-describedby="example1_info" style="width: 100%;">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Heading</th>
                                            <th>Description</th>
                                            <th>Code Url</th>
                                            <th style="text-align: center">Action</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <?php $__currentLoopData = $data_cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="odd">
                                            <td class="sorting_1"><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->heading_1); ?></td>
                                            <td><p><?php echo e($item->description_1); ?></p></td>
                                            <td><?php echo e($item->code); ?></td>
                                            <td style="text-align: center">
                                                <i class="fa fa-trash my-fa-delete"></i>
                                                <i class="fa fa-pencil-square-o my-fa-edit"></i>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('/public/backend')); ?>/assets/plugins/angular/controller/category.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>