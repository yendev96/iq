<?php $__env->startSection('title', 'Edit user'); ?>
<?php $__env->startSection('content'); ?>
<section class="panel">
    <div class="panel-heading my-panel-heading">
        <div class="row">
            <div class="col-md-4 col-ms-12 title-panel">
                <h3>Edit user</h3>
            </div>
            
        </div>
    </div>
    <div class="panel-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="margin-bottom-50">
                    <!-- Vertical Form -->
                    <form action="<?php echo e(url('backend/user/edit', $data->id)); ?>" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="row">
                            <?php if(count($errors) > 0): ?>
                            <div class="thongbaoloi text-center">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-danger">
                                    <?php echo e($err); ?><br>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="text" class="form-control name" name="email" value="<?php echo e($data->email); ?>" disabled="disabled">
                        </div>

                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" class="form-control username" name="username" value="<?php echo e($data->username); ?>">
                        </div>

                        <div class="form-group">
                            <label>Password</label>
                            <input type="text" class="form-control password" name="password">
                        </div>
                        <div class="form-group">
                            <label>Address</label>
                            <input type="text" class="form-control address" value="<?php echo e($data->address); ?>" name="address">
                        </div>
                        <div class="form-group">
                            <label>Phone Number</label>
                            <input type="text" class="form-control phone_number" value="<?php echo e($data->phone_number); ?>" name="phone_number">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Role</label>
                            <select name="role" class="form-control">
                                <option value="1" <?php if($data->role == 1): ?> <?php echo e('selected'); ?> <?php endif; ?>>Administrator</option>
                                <option value="2" <?php if($data->role == 2): ?> <?php echo e('selected'); ?> <?php endif; ?>>Editor</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" name="action-question" class="btn btn-primary width-150">Submit</button>
                        </div>
                    </form>
                    <!-- End Vertical Form -->
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>