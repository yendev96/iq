<!DOCTYPE html>
<html lang="en-US">
<head>
  <?php echo $__env->make('frontend.includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
  <div id="q-cont">
  <div class="slide" id="slide1">
    <div class="question">
      What's your name?
    </div>
    <div class="options">
      <span class="op" for="q1op1">Spartacus</span><span class="op op2" for="q1op2">Napolean</span><br /><span class="op" for="q1op3">Pope Francis</span><span class="op op2" for="q1op4">Other</span>
    </div>
  </div>
  <div class="slide" id="slide2">
    <div class="question">
      Your occupation?
    </div>
    <div class="options">
      <span class="op" for="q2op1">Greek Hero</span><span class="op op2" for="q2op2">French Leader</span><br /><span class="op" for="q2op3">Religious Leader</span><span class="op op2" for="q2op4">Other</span>
    </div>
  </div>
  <div class="slide" id="slide3">
    <div class="question">
      Year of birth?
    </div>
    <div class="options">
      <span class="op" for="q3op1">111 BC</span><span class="op op2" for="q3op2">1769</span><br /><span class="op" for="q3op3">1936</span><span class="op op2" for="q3op4">Other</span>
    </div>
  </div>
  <div class="slide" id="slide4">
    Well Done!
    <div class="re">
      Reset
    </div>
  </div>
</div>
</body>
</html>