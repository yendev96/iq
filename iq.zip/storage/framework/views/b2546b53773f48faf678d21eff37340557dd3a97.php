<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Title and Description -->
<title><?php echo $__env->yieldContent('title'); ?></title>
<meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
<link href="<?php echo e(asset('/public/backend')); ?>/assets/common/img/favicon.png" rel="icon" type="image/png">
<!-- Open Graph data -->
<meta property="og:locale" content="en_US" />
<meta property="og:title" content="><?php echo $__env->yieldContent('title'); ?>"/>
<meta property="og:type" content="website"/>
<meta property="og:url" content="<?php echo $__env->yieldContent('url'); ?>"/>
<meta property="og:image" content="https://maxconverter.net/img/favicons/favicon-260p.png"/>
<meta property="og:image:width" content="260"/>
<meta property="og:image:height" content="260"/>
<meta property="og:site_name" content="Test IQ Online"/>
<meta property="og:description" content="<?php echo $__env->yieldContent('description'); ?>"/>

<!-- Twitter Card data -->
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="<?php echo $__env->yieldContent('title'); ?>">
<meta name="twitter:description" content="<?php echo $__env->yieldContent('description'); ?>">
<meta name="twitter:image" content="https://maxconverter.net/img/favicons/favicon-260p.png">
<meta name="twitter:image:src" content="https://maxconverter.net/img/favicons/favicon-260p.png">
<meta name="twitter:url" content="<?php echo $__env->yieldContent('url'); ?>">

<!-- Css -->
<link rel="stylesheet" href="<?php echo e(asset('/public/frontend/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/public/frontend/css/style.css')); ?>">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<?php echo $__env->yieldContent('schema'); ?>
