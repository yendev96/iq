<div class="list-group">
	<a href="#" class="my-list-group-title">
		Categoies
	</a>
	<a href="<?php echo e(url('iq-test/for-kid')); ?>" class="list-group-item list-group-item-action">Test IQ for kid</a>
	<a href="<?php echo e(url('iq-test/for-adults')); ?>" class="list-group-item list-group-item-action">Test IQ for Adults</a>
	<a href="<?php echo e(url('eq-test/for-free')); ?>" class="list-group-item list-group-item-action">Test EQ</a>
	<a href="<?php echo e(url('member/high-iq')); ?>" class="list-group-item list-group-item-action">High IQ Member</a>
</div>
<div class="list-group">
	<a href="#" class="my-list-group-title">
		Articles
	</a>
	<a href="<?php echo e(url('iq-test/for-kid')); ?>" class="list-group-item list-group-item-action">Test IQ for kid
	</a>
	<a href="<?php echo e(url('iq-test/for-adults')); ?>" class="list-group-item list-group-item-action">Test IQ for Adults
	</a>
	<a href="<?php echo e(url('eq-test/for-free')); ?>" class="list-group-item list-group-item-action">Test EQ
	</a>
</div>