<?php $__env->startSection('title', 'Thông tin thành viên'); ?>
<?php $__env->startSection('content'); ?>
<section class="panel">

    <div class="panel-body">
        <div class="row">
            <div class="col-lg-12">

                <div class="container">
                  <div class="row">

                    <div class="col-md-10 col-md-offset-1" >


                      <div class="panel panel-info">
                        <div class="panel-heading heading-profile">
                          <h3 class="panel-title">Thông tin thành viên</h3>
                      </div>
                      <div class="panel-body">
                          <div class="row">
                            <div class="col-md-12"> 
                              <table class="table table-user-information">
                                <tbody>
                                  <tr>
                                    <td>ID:</td>
                                    <td><?php echo e($data->id); ?></td>
                                </tr>
                                <tr>
                                    <td>Email:</td>
                                    <td><?php echo e($data->email); ?></td>
                                </tr>
                                <tr>
                                    <td>Username</td>
                                    <td><?php echo e($data->username); ?></td>
                                </tr>

                                <tr>
                                 <tr>
                                    <td>Gender</td>
                                    <td>
                                        <?php if($data->gender == 1): ?>
                                        <?php echo e('Male'); ?>

                                        <?php elseif($data->gender == 0): ?>
                                        <?php echo e('Female'); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Home Address</td>
                                    <td><?php echo e($data->address); ?></td>
                                </tr>
                                
                                <td>Phone Number</td>
                                <td><?php echo e($data->phone_number); ?></td>

                            </tr>

                        </tbody>
                    </table>

                    <a href="<?php echo e(url('backend/users/edit', $data->id)); ?>" class="btn btn-primary">Edit profile</a>
                </div>
            </div>
        </div>
        

    </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>