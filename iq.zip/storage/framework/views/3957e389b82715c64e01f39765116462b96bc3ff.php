<?php $__env->startSection('title', 'Setting'); ?>
<?php $__env->startSection('content'); ?>
<section class="panel">
    <div class="panel-heading my-panel-heading">
        <div class="row">
            <div class="col-md-4 col-ms-12 title-panel">
                <h3>Setting</h3>
            </div>

        </div>
    </div>
    <div class="panel-body">
        <div class="row">
            <div class="col-lg-12">
                <!-- Vertical Form -->
                <form action="<?php echo e(url('backend/setting/edit', $data->id)); ?>" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="form-group">
                        <label for="l30">Site Title</label>
                        <input type="text" class="form-control site_title" id="cat_name" value="<?php echo e($data->site_title); ?>" name="site_title">
                    </div>
                    <div class="form-group">
                        <label for="l30">Site Description</label>
                        <input type="text" class="form-control site_description" id="site_description" value="<?php echo e($data->site_description); ?>" name="site_description">
                    </div>
                    <div class="form-group">
                        <label for="l30">Site URL</label>
                        <input type="text" class="form-control site_url" id="site_url" value="<?php echo e($data->site_url); ?>" name="site_url">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Language</label>
                        <select name="lang" class="form-control">
                            <option value="en-US" <?php if($data->lang == 'en-US'): ?> <?php echo e('selected'); ?> <?php endif; ?>>English</option>
                            <option value="vi" <?php if($data->lang == 'vi'): ?> <?php echo e('selected'); ?> <?php endif; ?>>Vietnamese</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Active Schema</label>
                        <select name="lang" class="form-control">
                            <option value="1" <?php if($data->lang == 1): ?> <?php echo e('selected'); ?> <?php endif; ?>>On</option>
                            <option value="0" <?php if($data->lang == 0): ?> <?php echo e('selected'); ?> <?php endif; ?>>Off</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <button type="submit" name="action-setting" class="btn btn-primary width-150">Submit</button>
                    </div>
                </form>
                <!-- End Vertical Form -->
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>