<?php $__env->startSection('title'); ?><?php echo e($data_cat->seo_title); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e($data_cat->seo_description); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('url'); ?><?php echo e(fullUrl()); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row box-content">
	<div class="box-item">
		<h1>Free psychological tests</h1>
		<p>Find out how smart you are, what you like to do, and what makes you happy with our free IQ tests, 
			career tests, and personality tests. All tests at 123test.com are designed to help you find serious 
		answers to your questions about IQ, personality, or career assessment.</p>
		<p>Tests are free, valid, and accurate. Although these tests are always fun to take, 
			they are much more than just for fun. We focus on giving you scientifically valid results 
		and reliable psychometrics that measure your personal preferences, mental traits, abilities, and processes.</p>
	</div>
	<div class="box-item">
		<h2>Personality test</h2>
		<p>
			Take our free personality test and find out more about who you are and 
			your strengths. This is valuable information for choosing a career and how to develop 
			yourself for personal growth. Five key personality dimensions are explored in 
			depth in a complete textual and graphical report.
		</p>
		<p>
			Choose a career that matches your preferences and you will 
			increase your chances of being successful! Take the career test now to learn more.
		</p>
		<button class="btn-play" title="">Play Test</button>
	</div>
</div>
<div class="box-play">

	<?php 
	$i = 0;
	?>
	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php 
	$i++;
	?>
	<div class="item-play" id="id<?php echo e($i); ?>">
		<div class="text-qus text-center">
			<p><?php echo e($i.'/26'.' - '); ?><?php echo e($item->question); ?></p>
		</div>
		<div class="img-qus">
			<img style="" src="<?php echo e(asset('public/upload/img_question')); ?>/<?php echo e($item->img); ?>" alt="">
			<div class="progress-counter"></div>
		</div>
		<div class="anwser">
			<div class="row">
				<div class="col-md-4 col-xs-6">
					<div class="anwser-item" data-id="<?php echo e($i); ?>" data-anwser="a" data-true="<?php echo e($item->anwser); ?>"><?php echo e($item->op1); ?></div>
				</div>
				<div class="col-md-4 col-xs-6">
					<div class="anwser-item" data-id="<?php echo e($i); ?>" data-anwser="b" data-true="<?php echo e($item->anwser); ?>"><?php echo e($item->op2); ?></div>
				</div>
				<div class="col-md-4 col-xs-6">
					<div class="anwser-item" data-id="<?php echo e($i); ?>" data-anwser="c" data-true="<?php echo e($item->anwser); ?>"><?php echo e($item->op3); ?></div>
				</div>
				<div class="col-md-4 col-xs-6">
					<div class="anwser-item" data-id="<?php echo e($i); ?>" data-anwser="d" data-true="<?php echo e($item->anwser); ?>"><?php echo e($item->op4); ?></div>
				</div>
				<?php if($item->op5 != ''): ?>
				<div class="col-md-4 col-xs-6">
					<div class="anwser-item" data-id="<?php echo e($i); ?>" data-anwser="e" data-true="<?php echo e($item->anwser); ?>"><?php echo e($item->op5); ?></div>
				</div>
				<?php endif; ?>
				<?php if($item->op6 != ''): ?>
				<div class="col-md-4 col-xs-6">
					<div class="anwser-item" data-id="<?php echo e($i); ?>" data-anwser="f" data-true="<?php echo e($item->anwser); ?>"><?php echo e($item->op6); ?></div>
				</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<div class="box-info">
		<form action="<?php echo e(url('check-iq')); ?>" method="post">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			<input type="hidden" class="count_true" name="count_true" value="0">
			<div class="row error-info text-center">
				<p>Do not leave empty</p>
			</div>
			<div class="form-group">
				<label for="l30">Full Name</label>
				<input type="text" class="form-control name" name="name">
			</div>
			<div class="form-group">
				<label for="l30">Email</label>
				<input type="email" class="form-control email" name="email">
			</div>
			<div class="form-group">
				<label for="l30">Country</label>
				<input type="text" class="form-control country" name="country">
			</div>
			<div class="form-group">
				<label for="l30">Year of Birth</label>
				<input type="text" class="form-control age" name="age">
			</div>
			<div class="form-group">
				<label class="form-label">Gender</label>
				<select name="gender" class="form-control gender">
					<option value="male">Male</option>
					<option value="female">Female</option>
				</select>
			</div>

			<div class="form-group">
				<button type="button" name="action-play" class="btn-result">View</button>
			</div>
		</form>
	</div>
	<div class="box-result text-center">
		<p class="p-result1">Congratulations <span class="name-play"></span> your IQ is:</p>
		<p class="p-iq"><span class="result-iq"></span>/200</p>
		
		<p class="p-result1">You answered correctly <span class="count-true-play"></span>/26 questions</p>
	</div>
	<div class="box-social">
		<div class="col-md-3 col-xs-6 item-social">
			<button type="button" name="action-play" class="btn-fb"><i class="fa fa-facebook-square"></i>Share</button>
		</div>
		<div class="col-md-3 col-xs-6 item-social">
			<a href="<?php echo e(url('eq-test/for-free')); ?>" class="btn-social btn-high-member"><i class="fa fa-users"></i> Test EQ</a>
		</div>
		<div class="col-md-3 col-xs-6 item-social">
			<button type="button" name="action-play" class="btn-social btn-reload"><i class="fa fa-play"></i> Test Again</button>
		</div>
		<div class="col-md-3 col-xs-6 item-social">
			<a href="<?php echo e(url('test-iq/high-iq-member')); ?>" class="btn-social btn-high-member"><i class="fa fa-users"></i> High IQ Members</a>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
	$(document).ready(function(){

			// var seconds = 20;
			// countDiv = document.getElementById('countdown'),
			// secondPass,
			// countDown = setInterval(function () {
			// 	"use strict";
			// 	secondPass();
			// }, 1000);
			// function secondPass() {
			// 	"use strict";
			// 	var minutes = Math.floor((seconds / 60)),
			// 	remSeconds = seconds % 60;
			// 	if (seconds < 10) {
			// 		remSeconds = "0" + remSeconds;
			// 	}
			// 	countDiv.innerHTML = minutes + ":" + remSeconds;
			// 	if (seconds > 0) {
			// 		seconds = seconds - 1;
			// 	} else {
			// 		clearInterval(countDown);
			// 		$('.item-play').hide();
			// 		$('.box-info').show();
			// 		$('#countdown').text('Time up');
			// 	}
			// }


			$('.btn-play').click(function(){
				$('.box-content').slideUp();
				$('#id1').show();
				//$('.box-countdown').show();

			})


			var progress = 3.846153846153846;

			$('.anwser-item').click(function(){
				var a = $(this).attr('data-id');
				var get_anwser = $(this).attr('data-true');
				var get_select = $(this).attr('data-anwser');
				if(get_anwser == get_select){
					var count_true = $('.count_true').attr('value');
					$('.count_true').attr('value', Number(count_true)+1);
				}

				$('#id'+ a).hide();
				var b = Number(a)+ 1;
				progress += 3.846153846153846;
				if(b <= <?php echo $data_count;?>){
					$('#id'+ b).show();
					$(".progress-counter").attr('style', 'width:' + progress + '%');
				}else{
				//clearInterval(countDown);
				$('.box-info').show();
			}
		})

			$('.btn-result').click(function(){
				var host       = window.location.protocol + "//" + window.location.host;
				var name       = $('.name').val();
				var age        = $('.age').val();
				var gender     = $('.gender').val();
				var country    = $('.country').val();
				var email      = $('.email').val();
				var count_true = $('.count_true').val();
				if(name == '' ||age == '' || gender == '' || email == ''){
					$('.error-info p').show();
				}else{
					$(this).html('Loading...');

					$.post(host + '/iq/iq-test/check-iq',
					{
						"_token": "<?php echo e(csrf_token()); ?>",
						name: name,
						age: age,
						country: country,
						gender: gender,
						email: email,
						count_true: count_true
					},
					function(data){

						setTimeout(function(){
							$('.box-info').hide();
							$('.name-play').text(name);
							$('.result-iq').text(data);
							$('.count-true-play').text(count_true);
							$('.box-result').show();
							$('.box-social').show();
						}, 3000);

					});
				}

			})

			$('.btn-reload').click(function(){
				$('.btn-play').click();
				$('.box-result').hide();
				$('.box-social').hide();
				$('.count_true').attr('value', 0);
				$('.btn-result').text('View');
				$(".progress-counter").attr('style', 'width:' + 3.846153846153846 + '%');
			})


		})

	</script>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>