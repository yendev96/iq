<?php $__env->startSection('title', 'Edit question'); ?>
<?php $__env->startSection('content'); ?>
<section class="panel">
    <div class="panel-heading my-panel-heading">
        <div class="row">
            <div class="col-md-4 col-ms-12 title-panel">
                <h3>Edit Question</h3>
            </div>
            
        </div>
    </div>
    <div class="panel-body">
        <div class="row">
            <form action="<?php echo e(url('backend/question/edit', $data->id)); ?>" method="post" enctype="multipart/form-data">
                <p class="p-error" style="color: red; font-size: 17px; text-align: center; display: none;">Không để trống</p>
                
                <div class="col-md-6">
                    <!-- Vertical Form -->
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="form-group">
                        <label for="l30">Name Question</label>
                        <input type="text" class="form-control name_question" value="<?php echo e($data->question); ?>" name="name_question">
                    </div>
                    <div class="form-group">
                        <label for="l30">Image</label>
                        <input type="file" class="form-control img_question upload_img" name="img_question">
                        <div class="show-img">
                            <img src="<?php echo e(asset('public/upload/img_question')); ?>/<?php echo e($data->img); ?>" class="" alt="">
                        </div>
                    </div>

                </div>
                <div class="col-md-6">

                    <div class="form-group">
                        <label for="l30">Option 1</label>
                        <input type="text" class="form-control op1" value="<?php echo e($data->op1); ?>" name="op1">
                    </div>

                    <div class="form-group">
                        <label for="l30">Option 2</label>
                        <input type="text" class="form-control op2" value="<?php echo e($data->op2); ?>" name="op2">
                    </div>
                    <div class="form-group">
                        <label for="l30">Option 3</label>
                        <input type="text" class="form-control op3" value="<?php echo e($data->op3); ?>" name="op3">
                    </div>
                    <div class="form-group">
                        <label for="l30">Option 4</label>
                        <input type="text" class="form-control op4" value="<?php echo e($data->op4); ?>" name="op4">
                    </div>
                    <div class="form-group">
                        <label for="l30">Option 5</label>
                        <input type="text" class="form-control op5" value="<?php echo e($data->op5); ?>" name="op5">
                    </div>
                    <div class="form-group">
                        <label for="l30">Option 6</label>
                        <input type="text" class="form-control op6" value="<?php echo e($data->op6); ?>" name="op6">
                    </div>
                    
                    <div class="form-group">
                        <label for="l30">Anwser true</label>
                        <select name="anwser_true" class="form-control anwser_true">
                            <option value="a" <?php if($data->anwser == 'a'): ?> <?php echo e('selected'); ?> <?php endif; ?>>A</option>
                            <option value="b" <?php if($data->anwser == 'b'): ?> <?php echo e('selected'); ?> <?php endif; ?>>B</option>
                            <option value="c" <?php if($data->anwser == 'c'): ?> <?php echo e('selected'); ?> <?php endif; ?>>C</option>
                            <option value="d" <?php if($data->anwser == 'd'): ?> <?php echo e('selected'); ?> <?php endif; ?>>D</option>
                            <option value="e" <?php if($data->anwser == 'e'): ?> <?php echo e('selected'); ?> <?php endif; ?>>E</option>
                            <option value="f" <?php if($data->anwser == 'f'): ?> <?php echo e('selected'); ?> <?php endif; ?>>F</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="l30">Level</label>
                        <select name="level" class="form-control level">
                            <option value="1" <?php if($data->level == 1): ?> <?php echo e('selected'); ?> <?php endif; ?>>Dễ</option>
                            <option value="2" <?php if($data->level == 2): ?> <?php echo e('selected'); ?> <?php endif; ?>>Bình thường</option>
                            <option value="3" <?php if($data->level == 3): ?> <?php echo e('selected'); ?> <?php endif; ?>>Khó</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="l30">Category</label>
                        <select name="category" class="form-control category">
                            <?php $__currentLoopData = $data_cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php if($data->cat_id == $item->id): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($item->name_cat); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group" style="margin-top: 44px;">
                        <button type="submit" name="action-question" class="btn btn-primary width-150 action-question">Submit</button>
                    </div>
                    
                </div>

            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $('.action-question').click(function(){
        var name_question = $('.name_question').val();
        var op1           = $('.op1').val();
        var op2           = $('.op2').val();
        var op3           = $('.op3').val();
        var op4           = $('.op4').val();
        var anwser_true   = $('.anwser_true').val();
        var level         = $('.level').val();
        var category      = $('.category').val();

        if(name_question == "" || op1 == "" || op2 == "" || op3 == "" || op4 == "" || anwser_true == "" || level == "" || category == ""){
            $('.p-error').show();
            return false;
        }
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>