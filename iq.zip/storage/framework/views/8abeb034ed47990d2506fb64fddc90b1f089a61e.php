<div class="logo-container">
    <?php if(session('success')): ?>
    <div class="alert alert-success message">
        <?php echo e(session('success')); ?>

    </div>
    <?php elseif(session('danger')): ?>
    <div class="alert alert-danger message">
        <?php echo e(session('danger')); ?>

    </div>
    <?php endif; ?>
    
    <a href="<?php echo e(url('/')); ?>" class="logo">
        <img src="<?php echo e(asset('/public/backend')); ?>/assets/common/img/logo.png" alt="Clean UI Admin Template" />
        <!-- <img class="logo-inverse" src="<?php echo e(asset('/public/backend')); ?>/assets/common/img/logo-inverse.png" alt="Clean UI Admin Template" /> -->
    </a>
</div>
<div class="left-menu-inner scroll-pane">
    <div class="header-aside">
        <span class="avatar avatar-aside">
            <a href="<?php echo e(url('backend/user/profile', Auth::guard('web')->user()->id)); ?>" title=""><img src="<?php echo e(asset('/public/backend')); ?>/assets/common/img/temp/avatars/1.jpg"></a>
        </span>
        <span class="id-aside-user">Hello : <a href="<?php echo e(url('backend/user/profile', Auth::guard('web')->user()->id)); ?>" title=""><?php echo e(Auth::guard('web')->user()->username); ?></a></span>
    </div>
    <ul class="left-menu-list left-menu-list-root list-unstyled my-left-menu-list-root" style="margin:0">
        <li class="left-menu-list-active">
            <a class="left-menu-link" href="<?php echo e(url('/backend/home')); ?>">
                <i class="left-menu-link-icon icmn-home2"><!-- --></i>
                <span class="menu-top-hidden">Dashboard</span> Alpha
            </a>
        </li>
        <li>
            <a class="left-menu-link" href="<?php echo e(url('backend/category')); ?>">
                <i class="left-menu-link-icon fa fa-folder"></i>Question Category
            </a>
        </li>
        <li>
            <a class="left-menu-link" href="<?php echo e(url('backend/question')); ?>">
                <i class="left-menu-link-icon ionicons fa fa-question-circle"></i>Questions Manager
            </a>
        </li>
        
        <li>
            <a class="left-menu-link" href="<?php echo e(url('backend/user')); ?>">
               <i class="left-menu-link-icon fa fa-users"></i>Users Manager
           </a>
       </li>
     <li>
        <a class="left-menu-link" href="<?php echo e(url('backend/post')); ?>">
            <i class="left-menu-link-icon fa fa-file-text"></i>Post Manager
        </a>
    </li>
    <li>
        <a class="left-menu-link" href="<?php echo e(url('backend/article')); ?>">
            <i class="left-menu-link-icon fa fa-folder"></i>Article Manager
        </a>
    </li>
    <li>
        <a class="left-menu-link" href="<?php echo e(url('backend/eq')); ?>">
            <i class="left-menu-link-icon fa fa-puzzle-piece"></i>EQ Result
        </a>
    </li>
    <!-- <li class="left-menu-list-submenu">
        <a class="left-menu-link" href="javascript: void(0);">
            <i class="left-menu-link-icon fa fa-file-text"></i>
            Post Manager
        </a>
        <ul class="left-menu-list list-unstyled sub-menu-aside">
            <li>
                <a class="left-menu-link" href="<?php echo e(url('backend/post')); ?>">
                    - Post
                </a>
            </li>
            <li>
                <a class="left-menu-link" href="<?php echo e(url('backend/post')); ?>">
                    - Category Manager
                </a>
            </li>
        </ul>
    </li> -->
    <li>
        <a class="left-menu-link" href="<?php echo e(url('backend/player')); ?>">
            <i class="left-menu-link-icon fa fa-play"></i>Player Manager
        </a>
    </li>
    <li>
        <a class="left-menu-link" href="<?php echo e(url('backend/social')); ?>">
            <i class="left-menu-link-icon fa fa-globe"></i>Social Manager
        </a>
    </li>
    <li>
        <a class="left-menu-link" href="<?php echo e(url('backend/setting')); ?>">
            <i class="left-menu-link-icon fa fa-cog"></i>Setting
        </a>
    </li>




</ul>
</div>