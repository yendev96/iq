<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $__env->yieldContent('title'); ?></title>
<meta name="description" content="<?php echo $__env->yieldContent('des'); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/public/frontend/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/public/frontend/css/style.css')); ?>">
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<link rel="stylesheet" href="<?php echo e(asset('/public/frontend/js/bootstrap.min.js')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/public/frontend/js/myjquery.js')); ?>">