<?php $__env->startSection('title','High IQ Members'); ?>
<?php $__env->startSection('description', 'High IQ Members'); ?>
<?php $__env->startSection('url'); ?><?php echo e(fullUrl()); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="title-high-member text-center">
	<h1>High IQ Member</h1>
</div>
<table class="table table-hover table-bordered">
	<thead>
		<tr>
			<th>Name</th>
			<th>Age</th>
			<th>Gender</th>
			<th>Country</th>
			<th class="tr-iq">IQ</th>
			<th class="tr-iq">EQ</th>
		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($item->name); ?></td>
			<td><?php echo e($item->age); ?></td>
			<td><?php echo e($item->gender); ?></td>
			<td><?php echo e($item->country); ?></td>
			<td class="td-iq"><?php echo e($item->iq); ?></td>
			<td class="td-iq"><?php echo e($item->eq); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<div class="row pull-right">
	<div class="col-sm-12">
		<?php echo e($data->links()); ?>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>