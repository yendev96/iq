<?php $__env->startSection('title', 'Quản lý bài viết'); ?>
<?php $__env->startSection('content'); ?>
<section class="panel">
    <div class="panel-heading my-panel-heading">
        <div class="row">
            <div class="col-md-4 col-ms-12 title-panel">
                <h3>Quản lý bài viết</h3>
            </div>
            
            <div class="button-addnew pull-right">
                <a href="<?php echo e(url('backend/post/add')); ?>" class="btn btn-danger margin-inline"><i class="fa fa-plus"></i> Add</a>
            </div>
        </div>
    </div>
    <div class="panel-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="margin-bottom-50">
                    <div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap4">
                        <div class="row">
                            <form action="<?php echo e(url('backend/user')); ?>" class="myformuser" method="get" accept-charset="utf-8">
                                <div class="col-md-6">
                                    <div class="dataTables_length" id="example1_length">
                                        <label>
                                            <select name="show" class="form-control showpage">
                                                <option value="10" <?php if(isset($_GET['show'])){ if($_GET['show'] == 10){ echo 'selected';}} ?>>10</option>
                                                <option value="25" <?php if(isset($_GET['show'])){ if($_GET['show'] == 25){ echo 'selected';}} ?>>25</option>
                                                <option value="50" <?php if(isset($_GET['show'])){ if($_GET['show'] == 50){ echo 'selected';}} ?>>50</option>
                                                <option value="100" <?php if(isset($_GET['show'])){ if($_GET['show'] == 100){ echo 'selected';}} ?>>100</option>
                                            </select>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div id="example1_filter" class="dataTables_filter">
                                        <input type="text" name="s" value="<?php if(isset($_GET['s'])){ echo $_GET['s'];} ?>" class="form-control input-sm">
                                        <button class="btn btn-success btn-search" type="submit"><i class="icmn-search"></i></button>
                                    </div>
                                </div>
                            </form>

                        </div>
                        <div class="row">
                            <div class="col-md-12" style="overflow: auto;">
                                <table class="table table-hover" id="example1" width="100%" role="grid" style="width: 100%;">
                                    <thead>
                                        <tr>
                                            <th>Email</th>
                                            <th>Username</th>
                                            <th>Role</th>
                                            <th>Create at</th>
                                            <th style="text-align: center">Action</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="odd">
                                            <td class="sorting_1"><?php echo e($item->email); ?></td>
                                            <td><?php echo e($item->username); ?></td>
                                            <td>
                                                <?php if($item->role == 1): ?> 
                                                <?php echo e('Administrator'); ?>

                                                <?php elseif($item->role == 2): ?>
                                                <?php echo e('Editor'); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($item->created_at); ?></td>
                                            <td style="text-align: center">
                                                <a href="<?php echo e(url('backend/users/delete', $item->id)); ?>" title=""><i class="fa fa-trash my-fa-delete delete-user"></i></a>
                                                <a href="<?php echo e(url('backend/users/edit', $item->id)); ?>" title=""><i class="fa fa-pencil-square-o my-fa-edit"></i></a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    
                                </table>
                                <div class="row">
                                    <?php echo e($data->links()); ?>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $('.delete-user').click(function(){
        if(confirm('Bạn có chắc chắn muốn xóa không?')){
            return true;
        }else{
            return false;
        }
    })

    $('.showpage').change(function(){
        $('.myformuser').submit();
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>