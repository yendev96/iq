<?php $__env->startSection('title', 'Player Manager'); ?>
<?php $__env->startSection('content'); ?>
<section class="panel">
    <div class="panel-heading my-panel-heading">
        <div class="row">
            <div class="col-md-4 col-ms-12 title-panel">
                <h3>Player Manager (<?php echo e(count($data)); ?>)</h3>
            </div>
        </div>
    </div>
    <div class="panel-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="margin-bottom-50">
                    <div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap4">
                        <div class="row">
                            <form action="<?php echo e(url('backend/player')); ?>" class="myformplayer" method="get" accept-charset="utf-8">
                                <div class="col-md-9">
                                    <div class="dataTables_length" id="example1_length">
                                        <label>
                                            <select name="show" class="form-control showpage">
                                                <option value="">Show</option>}
                                                <option value="10" <?php if(isset($_GET['show'])){ if($_GET['show'] == 10){ echo 'selected';}} ?>>10</option>
                                                <option value="25" <?php if(isset($_GET['show'])){ if($_GET['show'] == 25){ echo 'selected';}} ?>>25</option>
                                                <option value="50" <?php if(isset($_GET['show'])){ if($_GET['show'] == 50){ echo 'selected';}} ?>>50</option>
                                                <option value="100" <?php if(isset($_GET['show'])){ if($_GET['show'] == 100){ echo 'selected';}} ?>>100</option>
                                            </select>
                                        </label>
                                        <label>
                                            <select name="iq" class="form-control filter-iq" style="padding-right: 20px; width: 100px;">
                                                <option value="">IQ</option>}
                                                <option value="asc" <?php if(isset($_GET['iq'])){ if($_GET['iq'] == 'asc'){ echo 'selected';}} ?>>ASC</option>
                                                <option value="desc" <?php if(isset($_GET['iq'])){ if($_GET['iq'] == 'desc'){ echo 'selected';}} ?>>DESC</option>
                                            </select>
                                        </label>
                                        <label>
                                            <select name="gender" class="form-control filter-iq" style="padding-right: 20px; width: 100px;">
                                                <option value="">Gender</option>}
                                                <option value="male" <?php if(isset($_GET['gender'])){ if($_GET['gender'] == 'male'){ echo 'selected';}} ?>>Male</option>
                                                <option value="female" <?php if(isset($_GET['gender'])){ if($_GET['gender'] == 'female'){ echo 'selected';}} ?>>Female</option>
                                            </select>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div id="example1_filter" class="dataTables_filter">
                                        <input type="text" name="s" value="<?php if(isset($_GET['s'])){ echo $_GET['s'];} ?>" class="form-control input-sm">
                                        <button class="btn btn-success btn-search" type="submit"><i class="icmn-search"></i></button>
                                    </div>
                                </div>
                            </form>

                        </div>
                        <div class="row">
                            <form action="<?php echo e(url('backend/player/delete')); ?>" method="post">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <div class="col-md-12" style="overflow: auto;">
                                    <table class="table table-hover" id="example2" width="100%" role="grid" style="width: 100%;">
                                        <thead>
                                            <tr>
                                                <th class="check-table"><input type="checkbox" id="checkall" name="check_id" value=""></th>
                                                <th>Name</th>
                                                <th>IQ</th>
                                                <th>Email</th>
                                                <th>Age</th>
                                                <th>Gender</th>
                                                <th>Create at</th>
                                                <th style="text-align: right; padding-right: 35px;">Action</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="odd">
                                                <td><input type="checkbox" name="check_id[]" value="<?php echo e($item->id); ?>"></td>
                                                <td class="sort1"><?php echo e($item->name); ?></td>
                                                <td><?php echo e($item->iq); ?></td>
                                                <td><?php echo e($item->email); ?></td>
                                                <td><?php echo e($item->age); ?></td>
                                                <td><?php echo e($item->gender); ?></td>
                                                <td><?php echo e($item->created_at); ?></td>
                                                <td style="text-align: right;">
                                                    <a href="<?php echo e(url('backend/player/delete', $item->id)); ?>" title=""><i class="fa fa-trash my-fa-delete delete-user"></i></a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                    <div class="row bottom-page">
                                        <div class="col-md-6">
                                            <button type="submit" class="btn btn-danger margin-inline delete-user"><i class="icmn-bin"></i> Delete</button>
                                        </div>
                                        <div class="col-md-6"></div>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $('.delete-user').click(function(){
        if(confirm('Bạn có chắc chắn muốn xóa không?')){
            return true;
        }else{
            return false;
        }
    })

    $('.showpage').change(function(){
        $('.myformplayer').submit();
    })

    $('.filter-age').change(function(){
        $('.myformplayer').submit();
    })

    $('.filter-iq').change(function(){
        $('.myformplayer').submit();
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>