<!DOCTYPE html>
<html>
<head>
    <?php echo $__env->make('backend.includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="theme-default">
<nav class="left-menu" left-menu>
    <?php echo $__env->make('backend.includes.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</nav>
<nav class="top-menu">
    <?php echo $__env->make('backend.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</nav>

<section class="page-content">
<div class="page-content-inner">

    <!-- Dashboard -->
    <div class="dashboard-container">
        <div class="row">
           <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <!-- End Dashboard -->
</div>
</section>

<div class="main-backdrop"><!-- --></div>

<?php echo $__env->yieldContent('script'); ?>
</body>
</html>